package VolunEx;
import java.util.List;

public class Admin  {
    private String adID;
    private String adPW;
    private List<Volunteer> volList;
    
    Admin() {
        this.adID = null;
        this.adPW = null;
        this.volList = null;
    }
    Admin(String id, String pw) {
        this.adID = id;
        this.adPW = pw;
        this.volList = null;
    }
    /*public void addVolInfo(int volKey, )  {
    	String sql = null;
    	
    }*/
    public void adjVolInfo(int volKey)  {

    }
    public void delVolInfo(int volKey)  {

    }
    public void chkVolInfo(int volKey)  {

    }
}