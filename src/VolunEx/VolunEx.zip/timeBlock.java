package VolunEx;

public class timeBlock  {
	private int timeBlockNo;//timeBlock�� ������ ������ key
    public String title;//����
    //public String memo;//����
    public int sTime;//���۽ð�
    public int eTime;//����ð�
    public String day;//����
    public int color;//��
    public int valid;
    
    public int getDay() {
    	int i = 0;
    	for (i = 0; i < 7 ; i++) {
    		if(this.day.charAt(i)=='1')	{
    			return i;
    		}
    	}
    	return i;
    }
    
    public void settimeBlockNo(int blockNo)	{
    	this.timeBlockNo = blockNo;
    }
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setsTime(int sTime) {
		this.sTime = sTime;
	}
	public void seteTime(int eTime) {
		this.eTime = eTime;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public void setColor(int color) {
		this.color = color;
	}
    
}