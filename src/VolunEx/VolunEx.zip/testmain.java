package VolunEx;


public class testmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//MakeSQL sql = new MakeSQL();
		//System.out.println(sql.getStudentTotalNum());
		//System.out.print(1);
		Student student = new Student();
		StudentInfo sInfo = new StudentInfo();
		sInfo.sKey = 1;
		sInfo.age = 10;
		sInfo.home = "������ ���ʽ�";
		sInfo.name = "ȫ�浿";
		sInfo.ID = "abc";
		sInfo.PW = "123";
		sInfo.school = "����Ư���� ������";
		String loid = "abc";
		String lopw = "123";
		//student.joinNewAccount(sInfo);
		student.loginStudent(loid, lopw);
		/*
		System.out.println(student.getsInfo().homeCd[0]+" "+student.getsInfo().homeCd[1]);
		System.out.println(student.getsInfo().schoolCd[0]+" "+student.getsInfo().schoolCd[1]);
		System.out.println(student.getSchedule().get(0));
		sInfo.age = 20;
		sInfo.home = "����Ư���� ������";
		sInfo.school = "������ ���ʽ�";
		student.updateStudentInfo(sInfo);
		StudentInfo sInfo2 = new StudentInfo();
		sInfo2 = student.getsInfo();
		System.out.println(sInfo2.age+" "+student.getSchedule().get(0).title);
		*/
		ManageSchedule ms = new ManageSchedule(student);
		System.out.println("END");
	}
}
