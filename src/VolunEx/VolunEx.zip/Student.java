package VolunEx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Stack;

public class Student {
    private StudentInfo sInfo;
    private List<timeBlock> schedule;
    private List<Volunteer> volapplication;
    private Connection con;
	private Statement stmt;
	private ResultSet rs;
	
    public class Time{
    	int sTime, eTime;
    	public Time(){
    		sTime = eTime = 0;
    	}
    	public Time(int sTime, int eTime){
    		this.sTime = sTime;
    		this.eTime = eTime;
    	}
    }
    
    Student()  {
    	this.stmt = null;
        this.sInfo = new StudentInfo();
        this.schedule = new ArrayList<timeBlock>();
        this.volapplication = new ArrayList<Volunteer>();
        connectDB();
    }
    //sInfo�� ������ �л� ���� query �ޱ�
    /*
    Student(StudentInfo sInfo)	{
    	connectDB();
    	MakeSQL msql = new MakeSQL();
    	this.sInfo = new StudentInfo();
    	//�л� ���� �ޱ�
    	String sql = msql.selectStudentSQL(sInfo.ID, sInfo.PW);
    	executeSQL(sql);
    	try {
			while(rs.next()) {
				//������ ���� ����
				String sk = rs.getString(1);
				this.sInfo.sKey = Integer.parseInt(sk);
				this.sInfo.age = Integer.parseInt(rs.getString("age"));
				this.sInfo.name = rs.getString("sname");
				this.sInfo.ID = rs.getString("id");
				this.sInfo.PW = rs.getString("pw");
				this.sInfo.school = rs.getString("school");
				this.sInfo.home = rs.getString("home");
				this.sInfo.schoolCd = Integer.parseInt(rs.getString("schoolcd"));
				this.sInfo.homeCd = Integer.parseInt(rs.getString("homecd"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Select Execute SQL ERROR : "+e.getStackTrace());
		}
    	//�л��� ���� list�ޱ�
    	//sql = ;
    	//�л��� ������ list�ޱ�
    	//sql = msql.selectUserVolApp(sKey);
    }
    */
    Student(Student student) 	{
    	this.sInfo = student.sInfo;
    	this.schedule = student.schedule;
    	this.volapplication = student.volapplication;
    	connectDB();
    }
    public void finalize()	{
    	disconnectDB();
    	this.sInfo = null;
    	this.volapplication = null;
    	this.schedule = null;
    }
    //DB�� ������ �����Ѵ�.
    private void disconnectDB()	{
    	try {
    		if (con!=null)
    			con.close();
    		if (stmt!=null)
    			stmt.close();
    		if(rs!=null)
    			rs.close();
    	}
    	catch(SQLException e)	{
    		System.out.println("disconnection error"+e.getStackTrace());
    	}
    }
    //DB�� �����Ѵ�.
    private void connectDB()	{
    	String driver = "com.mysql.jdbc.Driver";
    	String url = "jdbc:mysql://localhost:3306/vtex";
    	String user = "root";
    	String pw = "dongdky11";
    	try {
    		Class.forName(driver);
    		con = DriverManager.getConnection(url, user, pw);
    		stmt = con.createStatement();
    	}
    	catch(ClassNotFoundException e)	{
    		System.out.println("load error"+e.getStackTrace());
    	}
    	catch(SQLException e) {
    		System.out.println("connection error"+e.getStackTrace());
    	}
    }
    //�ش��ϴ� sql���� ������ �Ŀ� resultSet�� �ִ´�.
    public void executeSQL(String sql)	{
    	ResultSet resultSet = null;
    	try {
    		//String[] msql = sql.split(" ");
    		if (sql.contains("select"))
    			resultSet = stmt.executeQuery(sql);
    		else
    			stmt.executeUpdate(sql);
    		System.out.println("EXECUTE SUCCESS");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("EXECUTE FAILED");
			e.printStackTrace();
		}
    	rs = resultSet;
    }
    //progrmRegistNo�� �ش��ϴ� �� ���� ������ �������ش�.
    public VolInfo showVolInfo(int progrmRegistNo)	{
    	VolInfo vInfo = new VolInfo();
    	MakeSQL mSQL = new MakeSQL();
    	String sql = mSQL.selectVolInfo(progrmRegistNo);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next()) {
				vInfo.actBeginTm = rs.getInt("actBeginTm");
				vInfo.actEndTm = rs.getInt("actEndTm");
				vInfo.actPlace  = rs.getString("actPlace");
				vInfo.actWkdy = rs.getString("actWkdy");
				vInfo.adultPosblAt = rs.getInt("adultPosblAt") == 1? true:false;
				vInfo.appTotal = rs.getInt("appTotal");
				vInfo.email = rs.getString("email");
				vInfo.mnnstNm = rs.getString("mnnstNm");
				vInfo.nanmmbyNm = rs.getString("nanmmbyNm");
				vInfo.progrmBgnde = rs.getString("progrmBgnde");
				vInfo.progrmCn = rs.getString("progrmCn");
				vInfo.progrmEndde = rs.getString("progrmEndde");
				vInfo.progrmSj = rs.getString("progrmSj");
				vInfo.telno = rs.getString("telno");
				vInfo.yngbgsPosblAt = rs.getInt("yngbgsPosblAt")==1?true:false;
				vInfo.rcritNmpr = rs.getInt("rcritNmpr");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return vInfo;
    }
    //�α����Ҷ� �ش��ϴ� loid, lopw�� ������ �л� ������ ������ �����´�.
    public void loginStudent(String loid, String lopw) {
    	MakeSQL mSQL = new MakeSQL();
    	String sql = mSQL.selectStudentSQL(loid, lopw);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next())	{
				this.sInfo.age = rs.getInt("age");
				this.sInfo.home = rs.getString("home");
				this.sInfo.homeCd[0] = rs.getInt("homesidoCode");
				this.sInfo.homeCd[1] = rs.getInt("homegugunCode");
				this.sInfo.ID = rs.getString("ID");
				this.sInfo.PW = rs.getString("PW");
				this.sInfo.sKey = rs.getInt("sKey");
				this.sInfo.school = rs.getString("school");
				this.sInfo.schoolCd[0] = rs.getInt("schoolsidoCode");
				this.sInfo.schoolCd[1] = rs.getInt("schoolgugunCode");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	//�л��� �������� �޾ƿ´�.
    	sql = mSQL.selectStudentSchedule(this.sInfo.sKey);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next())	{
				timeBlock tb =new timeBlock();
				tb.color = rs.getInt("color");
				tb.day = rs.getString("weekDate");
				tb.eTime = rs.getInt("Etime");
				tb.sTime = rs.getInt("Stime");
				tb.title = rs.getString("title");
				tb.valid = rs.getInt("valid");
				tb.settimeBlockNo(rs.getInt("stimekey"));
				this.schedule.add(tb);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	//�л��� ��û�� ������� ������ ���� ����Ʈ�� �޾ƿ´�.
    	sql = mSQL.selectStudentVolunteer(this.sInfo.sKey);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next())	{
				Volunteer vt = new Volunteer();
				vt.actBeginTm = rs.getInt("actBeginTm");
				vt.actEndTm = rs.getInt("actEndTm");
				vt.actPlace = rs.getString("actPlace");
				vt.adultPosblAt = rs.getInt("adultPosblAt")==1? true: false;
				vt.progrmSj = rs.getString("progrmSj");
				vt.progrmRegistNo = rs.getInt("progrmRegistNo");
				vt.actWkdy = rs.getString("actWkdy");
				this.volapplication.add(vt);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    //�л��� �ڽ��� ���������� update�� ���
    public void updateStudentInfo(StudentInfo sInfo)	{
    	MakeSQL mSQL = new MakeSQL();
    	StudentInfo sInfoTmp = sInfo;
    	String home[] = sInfo.home.split(" ");
    	String school[] = sInfo.school.split(" ");
    	//homecd�� ó�����ֱ�
    	String sql = mSQL.selectLocalCd(home[0], home[1]);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next()) {
				sInfoTmp.homeCd[0] = rs.getInt("sidocd");
				sInfoTmp.homeCd[1] = rs.getInt("gugunCd");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	//schoolcd�� ó�����ֱ�
    	sql = mSQL.selectLocalCd(school[0], school[1]);
    	this.executeSQL(sql);
    	try {
			while(this.rs.next()) {
				sInfoTmp.schoolCd[0] = rs.getInt("sidocd");
				sInfoTmp.schoolCd[1] = rs.getInt("guguncd");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	sql = mSQL.updateStudentSQL(sInfoTmp);
    	this.executeSQL(sql);
    }
    //���ο� �л����� �����ϱ�
    public void joinNewAccount(StudentInfo sInfo)	{
    	MakeSQL mSQL = new MakeSQL();
    	//sInfo�� �Է��� �� ������ �������� �����ڵ� �������ֱ�
    	String home[] = sInfo.home.split(" ");
    	int homeCd[] = new int[2];
    	String sql = mSQL.selectLocalCd(home[0], home[1]);
    	executeSQL(sql);
    	try {
			while(this.rs.next())	{
				homeCd[0] = rs.getInt("sidocd");
				homeCd[1] = rs.getInt("guguncd");
				System.out.println("Student's home address local code is SIDO:"+homeCd[0]+", GUGUN:"+homeCd[1]);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	sInfo.homeCd = homeCd;
    	//sInfo�� �Է��� �б� ������ �������� �����ڵ� �������ֱ�
    	String school[] = sInfo.school.split(" ");
    	int schoolCd[] = new int[2];
    	sql = mSQL.selectLocalCd(school[0], school[1]);
    	executeSQL(sql);
    	try {
			while(this.rs.next())	{
				schoolCd[0] = rs.getInt("sidocd");
				schoolCd[1] = rs.getInt("guguncd");
				System.out.println("Student's school address local code is SIDO:"+schoolCd[0]+", GUGUN:"+schoolCd[1]);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	sInfo.schoolCd = schoolCd;
    	
    	sql = mSQL.insertStudentSQL(sInfo);
    	executeSQL(sql);
    	
    }
    
    //////////////////////////////////////////////
    ///////////�ڽ��� ������ ������ ������ �޼ҵ��////////////
    //////////////////////////////////////////////
    
    //Ȯ�� ��ư�� ������ ��쿡 list�� �޴´�.
    public void updateSchedule(List<timeBlock> schedule)	{
    	MakeSQL mSQL = new MakeSQL();
    	
    	int curTimeKey = mSQL.getScheduleTotalNum() == 0 ? 1 : mSQL.getScheduleMaxlNum()+1;
    	
    	//���� �ִ� �����쿡�� ������ ����Ʈ
    	List<timeBlock> beDeleted = this.schedule;
    	//�̹��� ���� ������� ����Ʈ���� �߰��� ����Ʈ
    	List<timeBlock> beCreated = schedule;
    	
    	beDeleted.removeAll(beCreated);
    	beCreated.removeAll(this.schedule);
    	String sql;
    	
    }
    public List<timeBlock> getSchedule() {
        return schedule;
    }
    public StudentInfo getsInfo() {
        return sInfo;
    }
    public List<Volunteer> getvolapplication() {
        return volapplication;
    }
    public void setschedule(List<timeBlock> schedule) {
        this.schedule = schedule;
    }
    public void setsInfo(StudentInfo sInfo) {
        this.sInfo = sInfo;
    }
    public void setvolapplication(List<Volunteer> volapplication) {
        this.volapplication = volapplication;
    }
    //user ���� update SQL return

    //user �ð�ǥ ���� ����
    public void adjUserTime()   {

    }
    //user �ð�ǥ ���� �߰�
    public void addUserTime()   {

    }
    //user �ð�ǥ ���� ����
    public void delUserTime()   {

    }
    //user ���� ��û ���� �߰�
    public void addUserVol()    {

    }
    //user ���� ��û ���� ����
    public void delUserVol()    {

    }
    
    
}